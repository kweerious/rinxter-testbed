--
-- Table structure for table `bouts`
--
DROP DATABASE IF EXISTS dscore;
CREATE DATABASE dscore;
USE dscore;

GRANT ALL ON dscore.* TO 'rinxter'@'localhost' IDENTIFIED BY 'rinxter';

CREATE TABLE `bouts` (
  `bout_id` int(10) unsigned NOT NULL auto_increment,
  `team1_id` int(10) unsigned NOT NULL,
  `team2_id` int(10) unsigned NOT NULL,
  `team1_score` int(10) unsigned NOT NULL,
  `team2_score` int(10) unsigned NOT NULL,
  `half` int(10) unsigned NOT NULL,
  `venue` varchar(45) NOT NULL,
  `bout_date` datetime NOT NULL,
  `status` varchar(45) NOT NULL,
  `season` varchar(45) NOT NULL,
  `time_played` int(10) unsigned NOT NULL default '0',
  `league_id` int(10) unsigned NOT NULL default '0',
  `period_length` int(10) unsigned NOT NULL default '30',
  `max_periods` int(11) default '2',
  `use_clock` int(11) default '1',
  `team1_to` int(11) default '0',
  `team1_rv` int(11) default '0',
  `team2_to` int(11) default '0',
  `team2_rv` int(11) default '0',
  `sanction` varchar(10) default NULL,
  `tournament_id` int(10) unsigned NOT NULL default '0',
  `team1_rank` varchar(45) default NULL,
  `team1_capt` int(10) unsigned default NULL,
  `team1_cocapt` int(10) unsigned default NULL,
  `team2_rank` varchar(45) default NULL,
  `team2_capt` varchar(45) default NULL,
  `team2_cocapt` varchar(45) default NULL,
  `address` varchar(45) default NULL,
  `city` varchar(45) default NULL,
  `state` varchar(10) default NULL,
  `postcode` varchar(45) default NULL,
  `time_start` datetime NULL,
  `time_end` datetime NULL,
  `team1_mvp` int(10) unsigned default '0',
  `team2_mvp` int(10) unsigned default '0',
  `jam_length` int(10) default 120,
  `break_length` int(10) default 30,

  PRIMARY KEY  (`bout_id`),
  KEY `bouts_ix01` (`team1_id`,`team2_id`),
  KEY `bouts_ix02` (`team1_id`,`team2_id`,`venue`,`bout_date`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Table structure for table `broadcasts`
--

CREATE TABLE `broadcasts` (
  `bcast_id` int(10) unsigned NOT NULL auto_increment,
  `bcast_ts` bigint(20) unsigned NOT NULL,
  `bout_id` int(10) unsigned NOT NULL,
  `bout_desc` varchar(100) default NULL,
  `team1` varchar(45) default NULL,
  `team2` varchar(45) default NULL,
  `bcast_type` varchar(30) NOT NULL,
  `bout_period` int(10) unsigned NOT NULL,
  `bout_jam` int(10) unsigned NOT NULL,
  `period_clock` varchar(30) NOT NULL,
  `jam_clock` varchar(30) NOT NULL,
  `content` varchar(255) default NULL,
  PRIMARY KEY  (`bcast_id`),
  KEY `broadcast_ix01` (`bout_id`,`bcast_ts`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Table structure for table `downloads`
--

CREATE TABLE `downloads` (
  `download_id` int(10) unsigned NOT NULL auto_increment,
  `contact` varchar(100) NOT NULL,
  `email` varchar(45) NOT NULL,
  `league` varchar(45) NOT NULL,
  `url` varchar(45) default NULL,
  `rdate` datetime NOT NULL,
  PRIMARY KEY  (`download_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Table structure for table `fouls`
--

CREATE TABLE `fouls` (
  `lineup_id` int(10) unsigned NOT NULL,
  `foul` varchar(45) NOT NULL,
  `major` tinyint(1) NOT NULL,
  `tstamp` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `jtime` int(11) default '0',
  KEY `fouls_ix01` (`lineup_id`,`foul`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Table structure for table `haps`
--

CREATE TABLE `haps` (
  `lineup_id` int(10) unsigned NOT NULL auto_increment,
  `hap` varchar(30) NOT NULL,
  `hap_order` int(10) unsigned NOT NULL,
  `jtime` int(11) default '0',
  UNIQUE KEY `events_ix01` (`lineup_id`,`hap`,`hap_order`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Table structure for table `jams`
--

CREATE TABLE `jams` (
  `jam_id` int(10) unsigned NOT NULL auto_increment,
  `bout_id` int(10) unsigned NOT NULL,
  `jam_number` int(10) unsigned NOT NULL,
  `period` int(10) unsigned default NULL,
  `status` varchar(5) NOT NULL default 'P',
  `laps` decimal(10,4) NOT NULL default '0.0000',
  `jam_length` int(10) unsigned NOT NULL default '0',
  `team1_score` int(10) unsigned NOT NULL default '0',
  `team2_score` int(10) unsigned NOT NULL default '0',
  `team1_cum` int(10) unsigned NOT NULL default '0',
  `team2_cum` int(10) unsigned NOT NULL default '0',
  `term_state` varchar(3) default NULL,
  `period_clock` int(11) default '0',
  `notes` varchar(2000) default null,
  `notes_meta` varchar(100) default null,
  PRIMARY KEY  (`jam_id`),
  KEY `jams_ix01` (`bout_id`,`jam_number`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


--
-- Table structure for table `leagues`
--

CREATE TABLE `leagues` (
  `league_id` int(10) unsigned NOT NULL auto_increment,
  `name` varchar(45) NOT NULL,
  `short_name` varchar(10) NOT NULL,
  `location` varchar(60) null,
  `url` varchar(120) null,
  `region` varchar(60) null,
  `join_date` datetime null,
  PRIMARY KEY  (`league_id`),
  UNIQUE KEY `leagues_ix01` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Table structure for table `lineups`
--

CREATE TABLE `lineups` (
  `lineup_id` int(10) unsigned NOT NULL auto_increment,
  `jam_id` int(10) unsigned NOT NULL,
  `skater_id` int(10) unsigned NOT NULL,
  `position` varchar(45) NOT NULL,
  `lead` int(10) unsigned NOT NULL default '0',
  `scorer` int(11) default '0',
  `ptotal` int(11) default '0',
  `pstart` int(11) default '0',
  `pstop` int(11) default '0',
  `paggregate` int(11) default '0',
  `team_id` int(11) NOT NULL,
  `inbox` int(11) default '0',
  PRIMARY KEY  (`lineup_id`),
  KEY `lineups_ix01` (`jam_id`,`skater_id`,`position`,`team_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Table structure for table `monitors`
--

CREATE TABLE `monitors` (
  `monitor_id` int(10) unsigned NOT NULL auto_increment,
  `monitor_name` varchar(45) NOT NULL,
  `uri` varchar(150) default NULL,
  `last_access` datetime default NULL,
  `league_id` int(10) unsigned NOT NULL,
  `description` varchar(255) default NULL,
  PRIMARY KEY  (`monitor_id`),
  UNIQUE KEY `monitors_ix01` (`monitor_name`,`league_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Table structure for table `scores`
--

CREATE TABLE `scores` (
  `jam_id` int(10) unsigned NOT NULL auto_increment,
  `team_id` int(10) unsigned NOT NULL,
  `lap` int(10) unsigned NOT NULL,
  `score` int(10) unsigned NOT NULL,
  `scorer` varchar(1) default 'J',
  `jtime` int(11) default '0',
  PRIMARY KEY  (`jam_id`,`team_id`,`lap`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


--
-- Table structure for table `skater_teams`
--

CREATE TABLE `skater_teams` (
  `skater_id` int(10) unsigned NOT NULL,
  `team_id` int(10) unsigned NOT NULL,
  `status` varchar(1) character set latin1 collate latin1_bin NOT NULL default 'A',
  `roster` int(11) default '0',
  PRIMARY KEY  (`skater_id`,`team_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Table structure for table `skaters`
--

CREATE TABLE `skaters` (
  `skater_id` int(10) unsigned NOT NULL auto_increment,
  `name` varchar(45) NOT NULL,
  `number` varchar(45) NOT NULL,
  `primary_league_id` int(10) unsigned NOT NULL default '0',
  `seasons` int(11) default '0',
  PRIMARY KEY  (`skater_id`),
  UNIQUE KEY `skaters_ix01` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Table structure for table `teams`
--

CREATE TABLE `teams` (
  `team_id` int(10) unsigned NOT NULL auto_increment,
  `name` varchar(45) NOT NULL,
  `status` varchar(5) NOT NULL default 'A',
  `color1` varchar(20) default NULL,
  `color2` varchar(20) default NULL,
  `primary_league_id` int(10) unsigned NOT NULL default '1',
  `abbr_name` varchar(45) default NULL,
  `type` varchar(10) default NULL,
  PRIMARY KEY  (`team_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Table structure for table `user_leagues`
--

CREATE TABLE `user_leagues` (
  `league_id` int(10) unsigned NOT NULL auto_increment,
  `user_name` varchar(45) NOT NULL,
  PRIMARY KEY  (`league_id`,`user_name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Table structure for table `user_roles`
--

CREATE TABLE `user_roles` (
  `user_name` varchar(15) NOT NULL,
  `role_name` varchar(15) NOT NULL,
  PRIMARY KEY  (`user_name`,`role_name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_name` varchar(15) NOT NULL,
  `user_pass` varchar(15) NOT NULL,
  `primary_league_id` int(10) unsigned NOT NULL,
  `email` varchar(45) default NULL,
  PRIMARY KEY  (`user_name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE `subscribers` (
  `subscriber_id` INTEGER UNSIGNED NOT NULL AUTO_INCREMENT,
  `subscriber_name` VARCHAR(45) NOT NULL,
  `local_bout_id` INTEGER UNSIGNED NOT NULL,
  `remote_bout_id` INTEGER UNSIGNED,
  `server_uri` VARCHAR(120) NOT NULL,
  `username` VARCHAR(10),
  `password` VARCHAR(10),
  `frequency` INTEGER UNSIGNED NOT NULL,
  `last_ts` DATETIME,
  `sequence` INTEGER UNSIGNED,
  `status` VARCHAR(10),
  PRIMARY KEY (`subscriber_id`),
  INDEX `is_subsribers01`(`subscriber_name`,`local_bout_id` )
) ENGINE = InnoDB;

CREATE TABLE `bout_officials` (
  `bout_id` int(10) unsigned NOT NULL auto_increment,
  `official_id` int(10) unsigned NOT NULL,
  `designation` varchar(10) NOT NULL,
  `head` int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`bout_id`,`official_id`,`designation`)
) ENGINE=InnoDB;


CREATE TABLE `distributions` (
  `dist_version` varchar(10) NOT NULL,
  `posted_date` datetime NOT NULL
) ENGINE=InnoDB;


CREATE TABLE `official_designations` (
  `designation_id` int(10) unsigned NOT NULL auto_increment,
  `name` varchar(45) NOT NULL,
  `description` varchar(45) NOT NULL,
  `nso` tinyint(3) unsigned NOT NULL default '0',
  PRIMARY KEY  (`designation_id`),
  UNIQUE KEY `official_designations01` (`name`)
) ENGINE=InnoDB;

INSERT INTO `official_designations` (`designation_id`,`name`,`description`,`nso`) VALUES
 (1,'HR','Head Ref',0),
 (2,'OPR','Outside Pack Ref',0),
 (3,'IPR','Inside Pack Ref',0),
 (4,'JR','Jam Ref',0),
 (5,'SK','Score Keeper',1),
 (6,'SB','Score Board',1),
 (7,'PB','Penalty Box',1),
 (8,'PBM','',1),
 (9,'LU','',1),
 (10,'JT','Jam Timer',1),
 (11,'PT','Penalty Timer',1),
 (12,'PW','Penalty Wrangler',1),
 (13,'IWB','Inside White Board',1),
 (14,'OWB','Outside White Board',1);


CREATE TABLE `officials` (
  `official_id` int(10) unsigned NOT NULL auto_increment,
  `name` varchar(120) NOT NULL,
  `primary_league_id` int(10) unsigned NOT NULL default '0',
  `certification` varchar(45) default NULL,
  PRIMARY KEY  (`official_id`)
) ENGINE=InnoDB;

CREATE TABLE `tournaments` (
  `tournament_id` int(10) unsigned NOT NULL auto_increment,
  `name` varchar(45) NOT NULL,
  `description` varchar(45) NOT NULL,
  `season` varchar(45) NOT NULL,
  `type` varchar(10) default NULL,
  `start_date` datetime NOT NULL,
  `end_date` datetime default NULL,
  `url` varchar(45) default NULL,
  `venue` varchar(45) default NULL,
  `address` varchar(45) default NULL,
  `city` varchar(45) default NULL,
  `state` varchar(10) default NULL,
  `postcode` varchar(45) default NULL,
  PRIMARY KEY  (`tournament_id`),
  KEY `tournament_ix01` (`name`,`start_date`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

create table `version` (
  `version` varchar(30),
  `build` varchar(30),
  `dt` datetime
)ENGINE=InnoDB DEFAULT CHARSET=latin1;

CREATE TABLE `params` (
  `param_group_id` varchar(10) NOT NULL,
  `param_name` varchar(30) NOT NULL,
  `param_value` varchar(255) default NULL,
  UNIQUE KEY `params_ix01` (`param_group_id`,`param_name`)
)ENGINE=InnoDB DEFAULT CHARSET=latin1;


create table `promos` (
    `promo_id` int(10) unsigned NOT NULL auto_increment,
    `promo_name` varchar(60),
    `visible` int,
    `league_id` int,
    PRIMARY KEY (`promo_id`),
    INDEX `ix_promos01`(`promo_id`,`league_id` )
)ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE `rosters` (
  `bout_id` int(10) unsigned NOT NULL,
  `team_id` int(10) unsigned NOT NULL,
  `skater_id` int(10) unsigned NOT NULL,
  `skater_number` varchar(45) NOT NULL,
  UNIQUE KEY `rosters_ix01` (`bout_id`,`team_id`,`skater_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


create or replace view v_jam_lineups
as
select l.lineup_id, sk.skater_id, sk.name skater_name, sk.number jersey,  l.position, l.lead, l.scorer,
        t.team_id, t.name team_name, j.jam_id, j.jam_number, j.bout_id, j.status, j.period,
        l.ptotal, l.pstart, l.pstop, l.inbox
        from lineups l join jams j on l.jam_id=j.jam_id
                       join skaters sk on l.skater_id=sk.skater_id
                       join teams t on l.team_id=t.team_id;


INSERT INTO `users` (`user_name`,`user_pass`,`primary_league_id`,`email`) VALUES
 ('siteadmin','siteadmin',0,NULL);

INSERT INTO `user_roles` (`user_name`,`role_name`) VALUES
 ('siteadmin','siteadmin'),
 ('siteadmin','user');